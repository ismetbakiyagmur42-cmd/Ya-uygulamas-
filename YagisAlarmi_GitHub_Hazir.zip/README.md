# Yağış Alarmı — Android
Bu proje kişisel kullanım için hazırlanmış ilk sürümdür.

## Ne yapar?
- Her gün yaklaşık 07:45'te hava tahminini kontrol eder.
- Yağmur, kar veya dolu yağışı olasılığı %30 veya üzerindeyse yüksek sesli bildirim verir.
- Daha düşük olasılıkta bildirim göndermez.
- **Ana ekranda anlık bisiklet durumu gösterir**: uygulama açıldığında günün yağış tahminini çeker; %30 ve üzeri ihtimalde "🚫 Bisiklet süremezsin", altındaysa "✅ Bisiklet serbest" yazar. "🔄 Durumu Yenile" ile istediğin an tekrar sorgulanabilir.
- Konum izni verilirse telefonun konumunu kullanır; verilmezse Konya için varsayılan konum kullanılır.
- Hava verisi Open-Meteo'dan alınır; API anahtarı gerekmez.

## Kurulum gerektirmeden APK derleme (GitHub Actions)
Bu depoda `.github/workflows/build.yml` var. Bu dosyaları bir GitHub reposuna yükleyip "Actions" sekmesinden derlemeyi çalıştırırsan, hiçbir şey kurmadan indirilebilir bir `app-debug.apk` üretir.

## Derleme
Android Studio ile klasörü açıp Run/Build APK kullan.

## Bu sürümde yapılan iyileştirmeler
- **Launcher icon bağlandı**: `ic_launcher_background`/`ic_launcher_foreground` daha önce hiçbir yere referans verilmemişti; artık `mipmap-anydpi-v26/ic_launcher.xml` ile adaptif ikon olarak kullanılıyor.
- **Bildirim ikonu düzeltildi**: Durum çubuğunda tam renkli `ic_launcher` yerine tek renkli `ic_notification` gösteriliyor (Android'de renkli small icon genelde beyaz leke gibi görünür).
- **Tekrarlanan kod birleştirildi**: Alarm kurma mantığı `MainActivity`, `BootReceiver` ve `RainAlarmReceiver` içinde üç ayrı kopya hâlindeydi; artık hepsi `AlarmScheduler.scheduleNext()`'i çağırıyor. Aynı şekilde bildirim kanalı oluşturma da `NotificationHelper` içinde, hava durumu sorgusu ise `WeatherChecker` içinde tek yerde toplandı — hem alarm hem ana ekran aynı kodu kullanıyor.
- **Bisiklet durumu ekranı**: `MainActivity` artık açılışta `WeatherChecker` ile günün tahminini çekip ekranda "🚫 Bisiklet süremezsin" / "✅ Bisiklet serbest" gösteriyor, "🔄 Durumu Yenile" butonuyla tekrar sorgulanabiliyor.
- **`YagisAlarmiApp` (Application sınıfı)** eklendi: uygulama her açıldığında bildirim kanalını hazırlar ve alarmın hâlâ kurulu olduğundan emin olur (bazı üreticilerin pil optimizasyonu alarmı sessizce iptal edebiliyor).
- **BootReceiver** artık `QUICKBOOT_POWERON` aksiyonunu da dinliyor (bazı üreticiler `BOOT_COMPLETED` yerine bunu gönderir).
- **Manifest**: `ACCESS_NETWORK_STATE` izni, `allowBackup` için `backup_rules.xml`/`data_extraction_rules.xml` eklendi (yedeklenen tek şey `settings` SharedPreferences dosyası, konum bilgisi yedeklenmiyor).
