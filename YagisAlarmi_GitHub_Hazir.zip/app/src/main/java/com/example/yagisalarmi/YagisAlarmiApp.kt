package com.example.yagisalarmi

import android.app.Application

class YagisAlarmiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationHelper.ensureChannel(this)
        // Uygulama her açıldığında (boot dışında) alarmın hâlâ kurulu olduğundan
        // emin ol; bazı üreticilerin pil optimizasyonu alarmı sessizce iptal
        // edebiliyor, bu burada bir güvenlik ağı görevi görür.
        AlarmScheduler.scheduleNext(this)
    }
}
