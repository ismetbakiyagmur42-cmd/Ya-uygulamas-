package com.example.yagisalarmi

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build

/**
 * Bildirim kanalı oluşturma mantığı önceden MainActivity ve RainAlarmReceiver'da
 * ayrı ayrı tekrarlanıyordu. Tek bir yerde toplamak, ikisinin birbirinden
 * sapmasını (örn. farklı ses veya öncelik) engeller.
 */
object NotificationHelper {
    const val CHANNEL_ID = "rain_alarm"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Yağış Alarmı",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Yağış ihtimali yüksek olduğunda alarm"
                enableVibration(true)
                setSound(
                    Uri.parse("android.resource://${context.packageName}/${R.raw.sacma_alarm}"),
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
                )
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}
