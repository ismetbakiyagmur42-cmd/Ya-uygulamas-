package com.example.yagisalarmi

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Günlük yağış kontrol alarmını kuran tek nokta.
 *
 * Önceden bu mantık MainActivity, BootReceiver ve RainAlarmReceiver içinde
 * neredeyse aynı şekilde üç kez tekrarlanıyordu; biri değişip diğeri
 * güncellenmezse alarm saatleri birbirinden sapabilirdi. Artık hepsi
 * buradaki tek fonksiyonu çağırıyor.
 */
object AlarmScheduler {
    const val CHECK_HOUR = 7
    const val CHECK_MINUTE = 45
    private const val REQUEST_CODE = 7

    fun scheduleNext(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, RainAlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val now = LocalDateTime.now()
        var next = now.withHour(CHECK_HOUR).withMinute(CHECK_MINUTE).withSecond(0).withNano(0)
        if (!next.isAfter(now)) next = next.plusDays(1)

        val millis = next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pendingIntent)
    }
}
