package com.example.yagisalarmi

import android.content.Context
import android.location.LocationManager
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Bir hava durumu sorgusunun sonucu.
 * isRainy: eşik değerinin (THRESHOLD) üzerinde yağış ihtimali var mı.
 * maxProbability: günün en yüksek yağış ihtimali (%).
 * kind: "Yağmur" / "Kar" / "Yağış" (belirsizse).
 */
data class RainCheckResult(
    val isRainy: Boolean,
    val maxProbability: Int,
    val kind: String
)

/**
 * Open-Meteo sorgusu ve yağış değerlendirmesi önceden sadece
 * RainAlarmReceiver içindeydi. Ana ekranın da aynı veriye ihtiyacı olduğu
 * için mantık buraya taşındı; ikisi de aynı sonucu kullanıyor.
 */
object WeatherChecker {
    const val THRESHOLD = 30
    private const val DEFAULT_LAT = 37.8746 // Konya / Meram - konum izni yoksa
    private const val DEFAULT_LON = 32.4932

    /** Ağ çağrısı içerir — asla UI thread'inde doğrudan çağırma. */
    fun checkToday(context: Context): RainCheckResult? {
        return try {
            val (lat, lon) = lastKnownLocation(context)
            val url = URL(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&hourly=precipitation_probability,precipitation,rain,snowfall&forecast_days=1&timezone=auto"
            )
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 10000
            conn.readTimeout = 10000
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val hourly = JSONObject(text).getJSONObject("hourly")
            val probs = hourly.getJSONArray("precipitation_probability")
            val rain = hourly.getJSONArray("rain")
            val snow = hourly.getJSONArray("snowfall")
            val precip = hourly.getJSONArray("precipitation")

            var maxP = 0
            var kind = "Yağış"
            for (i in 0 until probs.length()) {
                val p = probs.optInt(i)
                if (p > maxP) maxP = p
                if (p >= THRESHOLD) {
                    kind = when {
                        snow.optDouble(i) > 0.0 -> "Kar"
                        rain.optDouble(i) > 0.0 -> "Yağmur"
                        precip.optDouble(i) > 0.0 -> "Yağış"
                        else -> kind
                    }
                }
            }
            RainCheckResult(isRainy = maxP >= THRESHOLD, maxProbability = maxP, kind = kind)
        } catch (_: Exception) {
            null
        }
    }

    private fun lastKnownLocation(context: Context): Pair<Double, Double> {
        var lat = DEFAULT_LAT
        var lon = DEFAULT_LON
        try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val gps = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (gps != null) {
                lat = gps.latitude; lon = gps.longitude
            } else {
                val net = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                if (net != null) { lat = net.latitude; lon = net.longitude }
            }
        } catch (_: SecurityException) {
            // İzin yoksa varsayılan konum kullanılır.
        }
        return lat to lon
    }
}
