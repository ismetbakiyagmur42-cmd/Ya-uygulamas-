package com.example.yagisalarmi

import android.Manifest
import android.app.NotificationManager
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    // İleride kullanıcı ayarları (eşik, saat, konum) eklenince burada saklanacak.
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val requestCode = 42

    private lateinit var bikeStatusView: TextView
    private lateinit var detailView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationHelper.ensureChannel(this)
        requestPermissionsIfNeeded()
        AlarmScheduler.scheduleNext(this)
        showHome()
        refreshBikeStatus()
    }

    private fun showHome() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 40, 28, 28)
            setBackgroundColor(Color.rgb(6, 21, 37))
        }
        val title = TextView(this).apply {
            text = "☔  Yağış Alarmı"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Yağmur • Kar • Dolu"
            textSize = 18f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        val timeText = String.format("%02d:%02d", AlarmScheduler.CHECK_HOUR, AlarmScheduler.CHECK_MINUTE)
        val status = TextView(this).apply {
            text = "Her sabah $timeText civarı kontrol edilir.\n%${WeatherChecker.THRESHOLD} ve üzeri yağış ihtimalinde alarm verir."
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(0, 32, 0, 20)
            gravity = Gravity.CENTER
        }

        bikeStatusView = TextView(this).apply {
            text = "🚲 Kontrol ediliyor..."
            textSize = 26f
            setTextColor(Color.LTGRAY)
            setPadding(0, 24, 0, 8)
            gravity = Gravity.CENTER
        }
        detailView = TextView(this).apply {
            text = ""
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, 20)
            gravity = Gravity.CENTER
        }

        val refresh = Button(this).apply {
            text = "🔄 Durumu Yenile"
            setOnClickListener { refreshBikeStatus() }
        }
        val test = Button(this).apply {
            text = "🔊 Alarmı Test Et"
            setOnClickListener { sendRainAlert("TEST", 99, "ŞAKA GİBİ YAĞIŞ ALARMI!") }
        }
        val info = TextView(this).apply {
            text = "📍 Konum: Cihaz konumu (izin yoksa Konya / Meram)\n⏰ Alarm: $timeText\n📊 Eşik: %${WeatherChecker.THRESHOLD}"
            textSize = 16f
            setTextColor(Color.rgb(53, 183, 255))
            setPadding(0, 20, 0, 20)
            gravity = Gravity.CENTER
        }

        box.addView(title)
        box.addView(subtitle)
        box.addView(status)
        box.addView(bikeStatusView)
        box.addView(detailView)
        box.addView(refresh)
        box.addView(info)
        box.addView(test)
        setContentView(box)
    }

    /** WeatherChecker ile ağ çağrısı yapar (arka plan thread) ve ekranı günceller. */
    private fun refreshBikeStatus() {
        bikeStatusView.text = "🚲 Kontrol ediliyor..."
        bikeStatusView.setTextColor(Color.LTGRAY)
        detailView.text = ""

        thread {
            val result = WeatherChecker.checkToday(this)
            runOnUiThread {
                if (result == null) {
                    bikeStatusView.text = "⚠️ Hava durumu alınamadı"
                    bikeStatusView.setTextColor(Color.LTGRAY)
                    detailView.text = "İnternet bağlantısını kontrol edip tekrar dene."
                } else if (result.isRainy) {
                    bikeStatusView.text = "🚫 Bisiklet süremezsin"
                    bikeStatusView.setTextColor(Color.rgb(255, 90, 90))
                    detailView.text = "${result.kind} ihtimali %${result.maxProbability}"
                } else {
                    bikeStatusView.text = "✅ Bisiklet serbest"
                    bikeStatusView.setTextColor(Color.rgb(120, 230, 140))
                    detailView.text = "Yağış ihtimali %${result.maxProbability} — eşiğin altında"
                }
            }
        }
    }

    private fun requestPermissionsIfNeeded() {
        val list = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) list += Manifest.permission.POST_NOTIFICATIONS
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            list += Manifest.permission.ACCESS_FINE_LOCATION
        if (list.isNotEmpty()) ActivityCompat.requestPermissions(this, list.toTypedArray(), requestCode)
    }

    private fun sendRainAlert(type: String, probability: Int, message: String) {
        val notification = NotificationCompat.Builder(this, NotificationHelper.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("🚨 YAĞIŞ ALARMI! 🚨")
            .setContentText("$message  Yağış ihtimali: %$probability")
            .setStyle(NotificationCompat.BigTextStyle().bigText("$message\nYağış ihtimali: %$probability\nTür: $type"))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(777, notification)
    }
}
