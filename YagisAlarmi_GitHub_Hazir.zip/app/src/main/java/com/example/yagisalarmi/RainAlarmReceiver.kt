package com.example.yagisalarmi

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import kotlin.concurrent.thread

class RainAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val pending = goAsync()
        thread {
            try {
                val result = WeatherChecker.checkToday(context)
                if (result != null && result.isRainy) {
                    show(context, result.kind, result.maxProbability)
                }
            } finally {
                AlarmScheduler.scheduleNext(context)
                pending.finish()
            }
        }
    }

    private fun show(context: Context, kind: String, p: Int) {
        NotificationHelper.ensureChannel(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(context, NotificationHelper.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("🚨🚨 YAĞIŞ ALARMI! 🚨🚨")
            .setContentText("$kind geliyor! İhtimal %$p — bisiklet yok!")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "UYAN! UYAN! 😭\n$kind yağışı ihtimali %$p.\nBugün bisiklet süremezsin, şemsiyeyi/kıyafeti hazırlamak iyi olabilir."
                )
            )
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .build()
        nm.notify(777, notification)
    }
}
